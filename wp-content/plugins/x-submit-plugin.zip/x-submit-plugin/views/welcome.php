<?php

?>

<div>
<h2>Welcome to X-Submit voting plugin. </h2>
<br>
<h4>To get started, follow the following instructions</h4>
</div>
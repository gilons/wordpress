</pre>
<form id="radioform">
 <table>
  <tbody>
   <tr>
    <td><input class="pref" checked="checked" name="book" type="radio" value="Sycamore Row" />Sycamore Row</td>
    <td>John Grisham</td>
   </tr>
   <tr>
    <td><input class="pref" name="book" type="radio" value="Dark Witch" />Dark Witch</td>
    <td>Nora Roberts</td>
   </tr>
  </tbody>
 </table>
</form>
<pre>
<?php
$x_submit_site_configs = [
    "url" => "https://localhost"
];
?>